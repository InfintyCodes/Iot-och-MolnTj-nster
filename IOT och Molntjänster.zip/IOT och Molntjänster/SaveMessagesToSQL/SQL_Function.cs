using IoTHubTrigger = Microsoft.Azure.WebJobs.EventHubTriggerAttribute;

using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Azure.EventHubs;
using System.Text;
using System.Net.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using SaveMessagesToSQL.Models;
using System;
using System.Data.SqlClient;

namespace SaveMessagesToSQL
{
    public static class SQL_Function
    {
        private static HttpClient client = new HttpClient();

        [FunctionName("SaveEventsToSQL")]
        public static void Run([IoTHubTrigger("messages/events", Connection = "ConnectionStringForIOTHUB")]EventData message, ILogger log)
        {
            log.LogInformation($"Message: {Encoding.UTF8.GetString(message.Body.Array)}");
            var msg = JsonConvert.DeserializeObject<DhtMeasurment>(Encoding.UTF8.GetString(message.Body.Array));
            using (var conn = new SqlConnection(Environment.GetEnvironmentVariable("SqlConnection")))
            {
                conn.Open();
                using (var cmd = new SqlCommand("", conn))
                {
                    cmd.CommandText = "INSERT INTO DhtMeasurement OUTPUT inserted.Id VALUES(@DeviceId, @Temperature, @Humidity, @epochTime)";
                    cmd.Parameters.AddWithValue("@DeviceId", msg.deviceId);
                    cmd.Parameters.AddWithValue("@Temperature", msg.temperature);
                    cmd.Parameters.AddWithValue("@Humidity", msg.humidity);
                    cmd.Parameters.AddWithValue("@epochTime", msg.epochTime);
                    cmd.ExecuteNonQuery();

                    return;
                }
            }

        }
    }
}